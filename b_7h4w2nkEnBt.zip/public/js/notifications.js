/* ============================================================
 *  Smart Agenda - Cliente de Notificaciones Programadas
 *  Estrategia híbrida (sin backend) que cubre:
 *    1. Notification Triggers API (Chrome/Edge: navegador cerrado OK)
 *    2. IndexedDB + Periodic Background Sync (PWA instalada)
 *    3. setTimeout en la página (fallback inmediato cuando está abierta)
 *  Expone: window.SmartNotifications.{ schedule, cancel, scheduleAll, init }
 * ============================================================ */
;(() => {
  const DB_NAME = "smart-agenda-db"
  const DB_STORE = "scheduled"

  /* ----- IndexedDB helpers ----- */
  function openDB() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, 1)
      req.onupgradeneeded = () => {
        const db = req.result
        if (!db.objectStoreNames.contains(DB_STORE)) {
          const store = db.createObjectStore(DB_STORE, { keyPath: "id" })
          store.createIndex("timestamp", "timestamp", { unique: false })
          store.createIndex("fired", "fired", { unique: false })
        }
      }
      req.onsuccess = () => resolve(req.result)
      req.onerror = () => reject(req.error)
    })
  }

  async function dbPut(item) {
    const db = await openDB()
    return new Promise((resolve, reject) => {
      const tx = db.transaction(DB_STORE, "readwrite")
      tx.objectStore(DB_STORE).put(item)
      tx.oncomplete = () => resolve()
      tx.onerror = () => reject(tx.error)
    })
  }

  async function dbDelete(id) {
    const db = await openDB()
    return new Promise((resolve, reject) => {
      const tx = db.transaction(DB_STORE, "readwrite")
      tx.objectStore(DB_STORE).delete(id)
      tx.oncomplete = () => resolve()
      tx.onerror = () => reject(tx.error)
    })
  }

  async function dbGetAll() {
    const db = await openDB()
    return new Promise((resolve, reject) => {
      const tx = db.transaction(DB_STORE, "readonly")
      const req = tx.objectStore(DB_STORE).getAll()
      req.onsuccess = () => resolve(req.result || [])
      req.onerror = () => reject(req.error)
    })
  }

  /* ----- Detección de soporte ----- */
  const supportsTriggers = "Notification" in window && "showTrigger" in Notification.prototype

  /* ----- API pública ----- */
  const SmartNotifications = {
    /**
     * Programa una notificación para que dispare en `timestamp` (ms epoch).
     * @param {object} opts { id, title, body, timestamp, tag, url }
     */
    async schedule(opts) {
      if (!opts || !opts.id || !opts.timestamp) {
        console.warn("[Notif] schedule: faltan id o timestamp", opts)
        return false
      }
      const item = {
        id: String(opts.id),
        title: opts.title || "Smart Agenda",
        body: opts.body || "Recordatorio",
        timestamp: Number(opts.timestamp),
        tag: opts.tag || `evt-${opts.id}`,
        url: opts.url || "/dashboard.html",
        fired: false,
      }

      // Si la fecha ya pasó, no hacemos nada
      if (item.timestamp <= Date.now()) return false

      // Persistir en IndexedDB (lo lee el SW al hacer periodicsync)
      try {
        await dbPut(item)
      } catch (e) {
        console.warn("[Notif] No se pudo guardar en IndexedDB:", e)
      }

      // Estrategia 1: Notification Triggers (navegador cerrado OK)
      if (supportsTriggers) {
        try {
          const reg = await navigator.serviceWorker.ready
          await reg.showNotification(item.title, {
            body: item.body,
            icon: "/logo.png",
            badge: "/icon.png",
            tag: item.tag,
            data: { url: item.url, scheduledId: item.id },
            requireInteraction: true,
            vibrate: [200, 100, 200],
            // Esta línea es la magia: la notificación queda programada
            // en el navegador y dispara aunque la app esté cerrada.
            showTrigger: new TimestampTrigger(item.timestamp),
          })
          return true
        } catch (e) {
          console.warn("[Notif] Triggers falló, usando fallback:", e)
        }
      }

      // Estrategia 2 (fallback): setTimeout mientras la pestaña esté abierta
      const delay = item.timestamp - Date.now()
      if (delay > 0 && delay < 2147483647) {
        // límite de setTimeout (~24.8 días)
        setTimeout(async () => {
          try {
            const reg = await navigator.serviceWorker.ready
            reg.showNotification(item.title, {
              body: item.body,
              icon: "/logo.png",
              badge: "/icon.png",
              tag: item.tag,
              data: { url: item.url },
              requireInteraction: true,
              vibrate: [200, 100, 200],
            })
          } catch {
            new Notification(item.title, { body: item.body, icon: "/logo.png", tag: item.tag })
          }
        }, delay)
      }

      return true
    },

    /** Cancela una notificación programada */
    async cancel(id) {
      try {
        await dbDelete(String(id))
      } catch (_) {}
      // Cerrar la programación en Triggers si existe
      try {
        const reg = await navigator.serviceWorker.ready
        const tag = `evt-${id}`
        const notifs = await reg.getNotifications({ tag, includeTriggered: true })
        notifs.forEach((n) => n.close())
      } catch (_) {}
    },

    /** Re-programa TODAS las notificaciones de los eventos del usuario activo.
     *  Primero cancela las que correspondían a eventos ya completados/eliminados
     *  para no dejar notificaciones fantasma flotando en el navegador.
     */
    async scheduleAll(eventos) {
      if (!Array.isArray(eventos)) return
      const ahora = Date.now()
      const idsActivos = new Set()

      // 1. Cancelar notificaciones de eventos completados (ya están agendadas
      //    pero ya no deben dispararse).
      for (const ev of eventos) {
        if (ev.completado) {
          await SmartNotifications.cancel(ev.id)
        } else {
          idsActivos.add(String(ev.id))
        }
      }

      // 2. Cancelar también cualquier item que esté en IndexedDB y no
      //    corresponda ya a ningún evento (evento eliminado).
      try {
        const stored = await dbGetAll()
        for (const item of stored) {
          if (item.tag && item.tag.startsWith("evento-")) {
            const idEv = item.tag.replace("evento-", "")
            if (!idsActivos.has(idEv)) await SmartNotifications.cancel(idEv)
          }
        }
      } catch (_) {}

      // 3. Programar las pendientes.
      for (const ev of eventos) {
        if (ev.completado) continue
        const fecha = ev.fecha
        const hora = ev.inicio || ev.hora
        if (!fecha || !hora) continue
        const fhEvento = new Date(`${fecha}T${hora}`).getTime()
        const antic = (Number.parseInt(ev.anticipacion) || 30) * 60 * 1000
        const ts = fhEvento - antic
        if (ts <= ahora) continue

        const ico = { tarea: "📋", proyecto: "📁", cena: "🍽️", reunion: "👥" }[ev.tipo] || "📅"
        const minAntes = Math.round((fhEvento - ts) / 60000)
        await SmartNotifications.schedule({
          id: ev.id,
          title: `⏰ ${ico} ${ev.titulo}`,
          body: `Comienza en ${minAntes} min (${hora})`,
          timestamp: ts,
          tag: `evento-${ev.id}`,
          url: "/dashboard.html",
        })
      }
    },

    /** Pide permisos y muestra estado */
    async requestPermission() {
      if (!("Notification" in window)) return "unsupported"
      if (Notification.permission === "granted") return "granted"
      if (Notification.permission === "denied") return "denied"
      const result = await Notification.requestPermission()
      return result
    },

    /** Inicializa: registra SW, pide permisos, intenta periodic sync */
    async init() {
      if (!("serviceWorker" in navigator)) return

      try {
        const reg = await navigator.serviceWorker.register("/sw.js", { scope: "/" })
        console.log("[Notif] SW registrado:", reg.scope)

        // Esperar a que esté activo
        await navigator.serviceWorker.ready

        // Intentar registrar periodic background sync (solo PWA instalada)
        if ("periodicSync" in reg) {
          try {
            const status = await navigator.permissions.query({ name: "periodic-background-sync" })
            if (status.state === "granted") {
              await reg.periodicSync.register("smart-agenda-check", {
                minInterval: 15 * 60 * 1000, // 15 min
              })
              console.log("[Notif] Periodic sync registrado")
            }
          } catch (e) {
            console.log("[Notif] Periodic sync no disponible:", e.message)
          }
        }

        // Pedir al SW que revise notificaciones pendientes ahora mismo
        if (reg.active) {
          reg.active.postMessage({ type: "CHECK_SCHEDULED" })
        }
      } catch (e) {
        console.warn("[Notif] Error registrando SW:", e)
      }
    },

    /** Devuelve true si el navegador soporta notificaciones con app cerrada */
    supportsBackground() {
      return supportsTriggers
    },
  }

  window.SmartNotifications = SmartNotifications
})()
