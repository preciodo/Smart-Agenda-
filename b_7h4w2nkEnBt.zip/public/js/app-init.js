/* ============================================================
 *  Smart Agenda - Inicialización común (PWA + Notificaciones)
 *  Se carga en TODAS las páginas. Idempotente.
 * ============================================================ */
;(() => {
  // 1. Registrar Service Worker e inicializar notificaciones
  if (window.SmartNotifications) {
    window.SmartNotifications.init()
  }

  // 2. Re-programar todas las notificaciones de los eventos del usuario
  //    al cargar cualquier página (cubre el caso de usuarios que entraron
  //    por primera vez en una página distinta del dashboard).
  document.addEventListener("DOMContentLoaded", () => {
    const usuario = localStorage.getItem("usuarioActivo")
    if (!usuario) return
    try {
      const eventos = JSON.parse(localStorage.getItem(`eventos_${usuario}`)) || []
      if (window.SmartNotifications && eventos.length) {
        window.SmartNotifications.scheduleAll(eventos)
      }
    } catch (e) {
      console.warn("[app-init] No se pudieron re-programar notificaciones:", e)
    }
  })

  // 3. Indicador de instalación PWA: guardamos el evento para usarlo si se necesita
  window.addEventListener("beforeinstallprompt", (e) => {
    e.preventDefault()
    window.deferredPWAInstall = e
  })

  // 4. PATCH: cuando cualquier página guarde la lista de eventos en localStorage,
  //    re-programamos automáticamente todas las notificaciones. Esto cubre
  //    agregar_evento.html, editar_evento.html y cualquier otro punto sin tener
  //    que tocar el código existente.
  const _origSetItem = Storage.prototype.setItem
  Storage.prototype.setItem = function (key, value) {
    _origSetItem.apply(this, arguments)
    try {
      if (typeof key === "string" && key.startsWith("eventos_") && window.SmartNotifications) {
        const eventos = JSON.parse(value) || []
        // Pequeño debounce para evitar tormentas si se hacen varios setItem seguidos
        clearTimeout(window.__sa_resched)
        window.__sa_resched = setTimeout(() => {
          window.SmartNotifications.scheduleAll(eventos)
        }, 200)
      }
    } catch (_) {
      /* ignorar */
    }
  }
})()
