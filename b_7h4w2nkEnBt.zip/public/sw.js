/* ============================================================
 *  Smart Agenda - Service Worker
 *  - Cache-first para carga ultra-rápida y soporte offline
 *  - Maneja clicks de notificaciones
 *  - Re-evalúa eventos al activarse (Periodic Background Sync)
 *  - Soporta Notification Triggers (programadas con navegador cerrado)
 * ============================================================ */

const CACHE_VERSION = "smart-agenda-v3"
const PRECACHE_URLS = [
  "/",
  "/index.html",
  "/login.html",
  "/register.html",
  "/dashboard.html",
  "/agregar_evento.html",
  "/editar_evento.html",
  "/habitos.html",
  "/chat.html",
  "/historial.html",
  "/configuracion.html",
  "/juegos.html",
  "/manifest.json",
  "/js/app-init.js",
  "/js/notifications.js",
  "/logo.png",
  "/icon.png",
]

/* -----------  INSTALL: precachear -----------  */
self.addEventListener("install", (event) => {
  event.waitUntil(
    caches
      .open(CACHE_VERSION)
      .then((cache) =>
        // addAll falla si UNO falla; usamos add individual con catch para tolerar 404
        Promise.all(
          PRECACHE_URLS.map((url) =>
            cache.add(url).catch((err) => console.warn("[SW] No se pudo cachear", url, err.message)),
          ),
        ),
      )
      .then(() => self.skipWaiting()),
  )
})

/* -----------  ACTIVATE: limpiar caches viejos -----------  */
self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE_VERSION).map((k) => caches.delete(k))))
      .then(() => self.clients.claim()),
  )
})

/* -----------  FETCH: estrategia stale-while-revalidate -----------  */
self.addEventListener("fetch", (event) => {
  const req = event.request
  if (req.method !== "GET") return
  // Solo manejamos same-origin
  const url = new URL(req.url)
  if (url.origin !== self.location.origin) return

  event.respondWith(
    caches.match(req).then((cached) => {
      const fresh = fetch(req)
        .then((res) => {
          // Solo cachear respuestas válidas
          if (res && res.status === 200 && res.type === "basic") {
            const copy = res.clone()
            caches.open(CACHE_VERSION).then((cache) => cache.put(req, copy))
          }
          return res
        })
        .catch(() => cached) // si offline, usa lo cacheado
      return cached || fresh
    }),
  )
})

/* -----------  NOTIFICATION CLICK -----------  */
self.addEventListener("notificationclick", (event) => {
  event.notification.close()
  const targetUrl = (event.notification.data && event.notification.data.url) || "/dashboard.html"

  event.waitUntil(
    self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((clientList) => {
      // Si ya hay una ventana abierta, enfócala
      for (const client of clientList) {
        if ("focus" in client) {
          client.navigate(targetUrl).catch(() => {})
          return client.focus()
        }
      }
      // Si no, abre una nueva
      if (self.clients.openWindow) {
        return self.clients.openWindow(targetUrl)
      }
    }),
  )
})

/* -----------  PERIODIC BACKGROUND SYNC -----------  */
self.addEventListener("periodicsync", (event) => {
  if (event.tag === "smart-agenda-check") {
    event.waitUntil(checkScheduledNotifications())
  }
})

/* -----------  SYNC (one-shot, fallback) -----------  */
self.addEventListener("sync", (event) => {
  if (event.tag === "smart-agenda-check") {
    event.waitUntil(checkScheduledNotifications())
  }
})

/* -----------  PUSH (preparado para futuro backend) -----------  */
self.addEventListener("push", (event) => {
  let data = { title: "Smart Agenda", body: "Tienes un recordatorio" }
  try {
    if (event.data) data = event.data.json()
  } catch (_) {}
  event.waitUntil(
    self.registration.showNotification(data.title, {
      body: data.body,
      icon: "/logo.png",
      badge: "/icon.png",
      tag: data.tag || "smart-agenda",
      data: { url: data.url || "/dashboard.html" },
      requireInteraction: true,
      vibrate: [200, 100, 200],
    }),
  )
})

/* -----------  MESSAGE: comunicación desde la página -----------  */
self.addEventListener("message", (event) => {
  const msg = event.data || {}
  if (msg.type === "CHECK_SCHEDULED") {
    event.waitUntil(checkScheduledNotifications())
  }
  if (msg.type === "SKIP_WAITING") {
    self.skipWaiting()
  }
})

/* ============================================================
 *  IndexedDB: store de notificaciones programadas
 *  Estructura: { id, userId, title, body, timestamp, tag, url, fired }
 * ============================================================ */
const DB_NAME = "smart-agenda-db"
const DB_STORE = "scheduled"

function openDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1)
    req.onupgradeneeded = () => {
      const db = req.result
      if (!db.objectStoreNames.contains(DB_STORE)) {
        const store = db.createObjectStore(DB_STORE, { keyPath: "id" })
        store.createIndex("timestamp", "timestamp", { unique: false })
        store.createIndex("fired", "fired", { unique: false })
      }
    }
    req.onsuccess = () => resolve(req.result)
    req.onerror = () => reject(req.error)
  })
}

async function getAllScheduled() {
  const db = await openDB()
  return new Promise((resolve, reject) => {
    const tx = db.transaction(DB_STORE, "readonly")
    const req = tx.objectStore(DB_STORE).getAll()
    req.onsuccess = () => resolve(req.result || [])
    req.onerror = () => reject(req.error)
  })
}

async function markFired(id) {
  const db = await openDB()
  return new Promise((resolve, reject) => {
    const tx = db.transaction(DB_STORE, "readwrite")
    const store = tx.objectStore(DB_STORE)
    const getReq = store.get(id)
    getReq.onsuccess = () => {
      const item = getReq.result
      if (item) {
        item.fired = true
        store.put(item)
      }
      resolve()
    }
    getReq.onerror = () => reject(getReq.error)
  })
}

/**
 * Revisa todas las notificaciones programadas y dispara las que ya tocaron.
 * Se llama desde periodicsync, sync y mensajes de la página.
 */
async function checkScheduledNotifications() {
  try {
    const all = await getAllScheduled()
    const now = Date.now()
    for (const item of all) {
      if (item.fired) continue
      if (item.timestamp <= now) {
        await self.registration.showNotification(item.title, {
          body: item.body,
          icon: "/logo.png",
          badge: "/icon.png",
          tag: item.tag || `evt-${item.id}`,
          data: { url: item.url || "/dashboard.html" },
          requireInteraction: true,
          vibrate: [200, 100, 200],
          renotify: true,
        })
        await markFired(item.id)
      }
    }
  } catch (e) {
    console.error("[SW] checkScheduledNotifications error:", e)
  }
}
