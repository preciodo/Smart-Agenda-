import { redirect } from "next/navigation"

// Redirige a la app HTML estática en /public/index.html
export default function RootPage() {
  redirect("/index.html")
}
